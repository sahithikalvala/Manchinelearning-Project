import pandas as pd
from sklearn.model_selection import train_test_split, GridSearchCV
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.tree import DecisionTreeClassifier
from sklearn import metrics
from sklearn.pipeline import Pipeline
from sklearn.feature_extraction.text import TfidfTransformer
import re
from nltk.corpus import stopwords
from nltk.stem.porter import PorterStemmer

# Load the dataset
data = pd.read_csv('sample_covid19_tweets.csv')

# Data cleaning - convert to lowercase
data['text'] = data['text'].apply(lambda x: x.lower())

# Remove non-alphabetic characters, stop words, and perform stemming
stemmer = PorterStemmer()
stop_words = set(stopwords.words('english'))
data['text'] = data['text'].apply(lambda x: ' '.join(stemmer.stem(word) for word in re.sub(r'\W', ' ', str(x)).split() if word not in stop_words))

# Split the data into train and test sets
X_train, X_test, y_train, y_test = train_test_split(data['text'], data['sentiment'], test_size=0.2)

# Build the pipeline
text_clf = Pipeline([('vect', CountVectorizer()),
                     ('tfidf', TfidfTransformer()),
                     ('clf', DecisionTreeClassifier()),
])

# Grid search for hyperparameters
parameters = {'vect__ngram_range': [(1, 1), (1, 2)],
              'tfidf__use_idf': (True, False),
              'clf__max_depth': [10, 50, 100, None],
}

gs_clf = GridSearchCV(text_clf, parameters, cv=4)
gs_clf.fit(X_train, y_train)

# Predict sentiments on the test set
predictions = gs_clf.predict(X_test)

# Calculate accuracy
accuracy = metrics.accuracy_score(y_test, predictions)
print(f"Accuracy: {accuracy * 100}%")
