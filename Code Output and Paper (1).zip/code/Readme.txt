=== Sentiment Analysis Scripts ===
This project contains sentiment analysis scripts using machine learning models implemented in Python. Models used are the Multinomial Naive Bayes classifier and Decision Tree Classifier.

Instructions to run the programs:
1. Ensure that Python 3 and the necessary packages (pandas, scikit-learn, nltk, and re) are installed on your system. You can install them using pip:

   pip install pandas scikit-learn nltk

2. Download or clone the scripts from the repository to your local system.

3. The scripts expect CSV files as input datasets. We use `sample_amazon_reviews.csv` for the Naive Bayes script and `sample_covid19_tweets.csv` for the Decision Tree script. You should place these files in the same directory as the scripts. You can create these CSV files by simply copying the sample records provided in the project description to corresponding files.

4. To run the scripts, navigate to the directory containing the scripts and datasets in a terminal or command prompt, then use the following commands:

   For the Naive Bayes classifier script:
   python naive_bayes_script.py

   For the Decision Tree Classifier script:
   python decision_tree_script.py

The scripts will output the accuracy of the sentiment predictions on the console.

Note: The scripts and datasets provided are for demonstration and learning purposes only. For robust sentiment analysis tasks, you'd typically use much larger and diverse datasets. You can find such datasets on platforms like Kaggle, UCI Machine Learning Repository, or by using APIs of platforms like Twitter, Amazon, etc. Always ensure to respect privacy and use data responsibly.


Sentiment analysis datasets often come from sources such as reviews websites, social platforms, and movie databases. Here are direct links to the sentiment analysis datasets similar to what we described in our examples:

1. For "COVID-19 Twitter data", a relevant dataset on Kaggle is the "Coronavirus (Covid-19) Tweets" dataset, which can be found at the following link: [Coronavirus (Covid-19) Tweets dataset](https://www.kaggle.com/datatattle/covid-19-nlp-text-classification)

2. For "Amazon reviews", the Amazon Review dataset provided by the Stanford Network Analysis Project (SNAP) could be very helpful: [Amazon Review Data](http://jmcauley.ucsd.edu/data/amazon/)

Please note that it is essential to respect the privacy and terms of use of the dataset. Some datasets may require permission from the authors before they can be utilized for specific purposes. Furthermore, these datasets are large and might not be directly used in your local environment without substantial computing resource. You may need to extract a portion of these datasets for your experimental setups.